# Serial of arguments

#~ MM = sys.argv[1]  # time
#~ DD = sys.argv[2]  # data budget
#~ UU = sys.argv[3]  # upload interval
#~ CC = sys.argv[4]  # choice 1 2 3
#~ PP = sys.argv[5]  # period update # fix at 30
 

#~ python dispatcher.py 200 20000 20 1 40 
#~ python dispatcher.py 200 40000 20 1 40 
#~ python dispatcher.py 200 60000 20 1 40 |
#~ python dispatcher.py 200 80000 20 1 40 |

#~ python dispatcher.py 200 40000 20 2 40
#~ python dispatcher.py 200 20000 20 2 40 
#~ python dispatcher.py 200 40000 20 2 40 |
#~ python dispatcher.py 200 60000 20 2 40 |
#~ python dispatcher.py 200 80000 20 2 40 |

#~ python dispatcher.py 200 20000 20 3 40 
#~ python dispatcher.py 200 40000 20 3 40 |
#~ python dispatcher.py 200 60000 20 3 40 |
#~ python dispatcher.py 200 80000 20 3 40 

python dispatcher.py 200 20000 20 1 40  && \
python dispatcher.py 200 20000 20 2 40  && \
python dispatcher.py 200 20000 20 3 40  && \

python dispatcher.py 200 40000 20 1 40  && \
python dispatcher.py 200 40000 20 2 40  && \
python dispatcher.py 200 40000 20 3 40  && \


python dispatcher.py 200 60000 20 1 40  && \
python dispatcher.py 200 60000 20 2 40  && \
python dispatcher.py 200 60000 20 3 40  && \


python dispatcher.py 200 80000 20 1 40  && \
python dispatcher.py 200 80000 20 2 40  && \
python dispatcher.py 200 80000 20 3 40  
