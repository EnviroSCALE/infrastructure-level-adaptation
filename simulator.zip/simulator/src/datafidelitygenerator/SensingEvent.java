package datafidelitygenerator;

/**
 *
 * @author Hera
 */
public class SensingEvent extends Event {
    
    Sensor s;
    
    @Override
    public void processEvent(Simulator sim) {
        //System.out.println("Sensing Event triggerred at " + sim.simClock);
        if (!sim.samplingOn) return; // pruning data
        if (this.s.type == 0) { // physical, periodic
            // collect sample, add to Q
            ReadingSample sample = s.getReading(sim.simClock);
            //System.out.println("Collected sample: " + sample.toString());
            sim.readingQueue.add(sample);
            //System.out.println("Queue Size now: " + sim.getReadingQueueByteSize());
            
            // next sensing event schedule
            double period = 1.0/this.s.f;
            sim.eventQueue.add( new SensingEvent(sim.simClock+period, s) );
        } else if (this.s.type == 1) { // virtual, periodic
            ReadingSample sample = s.getReading(sim.simClock);
            if (sim.random.nextDouble() < 1-s.f/s.F ) {
                return;
            }
            sim.readingQueue.add(sample);
            double period = 1.0/this.s.f;
            sim.eventQueue.add( new SensingEvent(sim.simClock+period, s) );
        } else if (this.s.type == 2) { // event-triggered, aperiodic
            sim.totalUploaded += 2048;
            sim.eventQueue.add( new PeriodUpdateEvent(sim.simClock) );
        }
    }
    
    SensingEvent(double eventTime, Sensor s) {
        super(eventTime);
        this.s = s;
    }
    
}
