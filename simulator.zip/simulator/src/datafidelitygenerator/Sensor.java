package datafidelitygenerator;

import java.io.FileNotFoundException;

/**
 *
 * @author Hera
 */
public class Sensor {

    public Sensor(String name, double F, int type, int byteSize, String traceFileName, int id) throws FileNotFoundException {
        this.name = name;
        this.F = F;
        this.type = type;
        this.byteSize = byteSize;
        this.trace = new DataTrace(traceFileName, id);
        this.f = F;
        this.id = id;
    }
    
    String name;
    double F;
    int type;
    int byteSize;
    DataTrace trace;
    double f;
    int id;
    
    public ReadingSample getReading(double time) {
        double v = this.trace.getReading(time);
        double t = time;
        return new ReadingSample(t, v, this.id);
    }
    
}
