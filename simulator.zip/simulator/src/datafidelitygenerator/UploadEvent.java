package datafidelitygenerator;

import java.util.LinkedList;
import java.util.List;

/**
 *
 * @author Hera
 */
public class UploadEvent extends Event {
    
    @Override
    public void processEvent(Simulator sim) {
        // give messages
        //System.out.println("Upload Event triggerred at " + sim.simClock);
        int sizeToUpload = sim.getReadingQueueByteSize();
        //System.out.println("Queue size in bytes: " + sizeToUpload);
        
        
        // put samples to reconstructed data streams
        for (ReadingSample sample : sim.readingQueue) {
            int id = sample.sensorID;
            sim.uploadedSamples.get(id).add(sample);
        }
        
        // after uploading, all are empty, give stats again
        sim.readingQueue = new LinkedList<ReadingSample>();
        //System.out.println("Now size: " + sim.getReadingQueueByteSize());
        sim.totalUploaded += sizeToUpload + sim.alpha;
        //System.out.println("So far uploaded: " + sim.totalUploaded);
        sim.eventQueue.add( new UploadEvent(sim.simClock+sim.UploadInterval) );
        
        // update the periods
        sim.eventQueue.add ( new PeriodUpdateEvent(sim.simClock+0.01) );
    }
    // TODO: separate streams
    
    UploadEvent(double eventTime) {
        super(eventTime);
    }
    
}
