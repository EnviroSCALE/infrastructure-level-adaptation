
package datafidelitygenerator;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

/**
 *
 * @author Hera
 * Assume that: min time = 0
 * Also, times are sorted
 */
public class DataTrace {

    public double getMaxTime() {
        return this.samples[samples.length-1].time;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
    
    String filename;
    String name;
    int id;
    
    ReadingSample[] samples;
    
    double maxTime;
    
    public String details () {
        return name + " id " + id;
    }
    
    DataTrace (String filename, int id) throws FileNotFoundException {
        this.filename = filename;
        this.id = id;
        fileparser();
    }
    
    DataTrace (String filename, String name, int id) throws FileNotFoundException {
        this.filename = filename;
        this.id = id;
        this.name = name;
        fileparser();
    }
    
    DataTrace (ReadingSample[] samples, int id) {
        this.samples = samples;
        this.id = id;
        this.maxTime = samples[samples.length - 1].time;
    }
    
    
    private void fileparser() throws FileNotFoundException {
        Scanner scanner = new Scanner(new File(filename));
        int numReadings = scanner.nextInt();
        samples = new ReadingSample[numReadings];
        for (int i = 0; i < numReadings; i++) {
            samples[i] = new ReadingSample(scanner.nextDouble(), scanner.nextDouble(), this.id);
        }
        this.maxTime = samples[numReadings - 1].time;
    }
    
    public double getReading(double time) {
        ReadingSample previousSample = this.samples[0];
        for (ReadingSample currentSample : this.samples) {
            if (time == currentSample.time) {
                return currentSample.reading;
            }
            if (time == previousSample.reading) {
                return previousSample.reading;
            }
            if (time <= currentSample.time && time >= previousSample.time) {
                return (time - previousSample.time)/(currentSample.time - previousSample.time)*(currentSample.reading - previousSample.reading) + previousSample.reading;
            }
            previousSample = currentSample;
        }
        return -1;
    }
    
    void printReadings() {
        for (ReadingSample s : samples) {
            System.out.println(s.time + " " + s.reading);
        }
        System.out.println("Max time: " + this.getMaxTime());
    }
    
}
