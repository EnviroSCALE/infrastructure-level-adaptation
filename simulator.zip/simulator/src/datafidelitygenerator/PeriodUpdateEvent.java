package datafidelitygenerator;

/**
 *
 * @author Hera
 */
public class PeriodUpdateEvent extends Event {
    
    @Override
    public void processEvent(Simulator sim) {
        
        int bytesLeft = sim.D - sim.totalUploaded;
        double timeLeft = sim.M - sim.simClock;
        double maxUploadRate = 1.0 * bytesLeft / timeLeft;
        double A = maxUploadRate - 1.0*sim.alpha/sim.UploadInterval;
        if ( A < 0 ) {
            sim.samplingOn = false;
            //System.out.println(A);
            //System.out.println("----------------------------------------");
            sim.eventQueue.add( new PeriodUpdateEvent(sim.simClock + 5.0) );
            return;
        } else {
            sim.samplingOn = true;
        }
        if (sim.choice == 1) {
            for (Sensor s : sim.sensors) {
                s.f = A / (sim.numSensors * s.byteSize);
            }
        } else if (sim.choice == 2) {
            double[] w = new double [sim.sensors.length];
            double sum = 0;
            for (int i = 0; i < sim.numSensors; i++) {
                w[i] = sim.getCV(i);
                sum += w[i];
            }
            for (int i = 0; i < sim.numSensors; i++) {
                w[i] =  w[i] / sum;
            }
            for (int i = 0; i < sim.numSensors; i++) {
                sim.sensors[i].f = (A*w[i]) / (sim.sensors[i].byteSize);
            }
        } else {
            double sum_si_Fi = 0.0;
            for (Sensor s : sim.sensors) {
                sum_si_Fi += s.byteSize*s.F;
            }
            double del = sum_si_Fi - A;
            if (del <= 0) {
                //System.out.println("----------------------------------------");
                return;
            }
            double[] w = new double [sim.sensors.length];
            double sum = 0;
            for (int i = 0; i < sim.numSensors; i++) {
                w[i] = sim.getCV(i);
                sum += w[i];
            }
            for (int i = 0; i < sim.numSensors; i++) {
                w[i] =  w[i] / sum;
            }
            double sum_si_wi = 0.0;
            for (int i = 0; i < sim.numSensors; i++) {
                sum_si_wi += sim.sensors[i].byteSize/w[i];
            }
            for (int i = 0; i < sim.numSensors; i++) {
                sim.sensors[i].f = Math.max(sim.sensors[i].F - del*(sim.sensors[i].byteSize/w[i])/sum_si_wi, 0.5);
                if (sim.sensors[i].f > sim.sensors[i].F) sim.sensors[i].f = sim.sensors[i].F;
                //System.out.println("----------------------------------------");
                //System.out.println(sim.sensors[i].f);
                //System.out.println(sim.sensors[i].F);
                //System.out.println("----------------------------------------");
            }
        }
        sim.eventQueue.add( new PeriodUpdateEvent(sim.simClock+10) );
        //System.out.println(sim.simClock + " " + sim.sensors[2].f);
    }
    
    PeriodUpdateEvent(double eventTime) {
        super(eventTime);
    }
    
}
