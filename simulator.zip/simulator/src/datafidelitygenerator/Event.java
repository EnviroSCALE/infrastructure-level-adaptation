package datafidelitygenerator;

/**
 *
 * @author user
 */
public abstract class Event {
    
    public boolean isEndEvent = false;

    public Event(double eventTime) {
        this.eventTime = eventTime;
    }
    
    double eventTime;
    
    double getEventTime() {
        return eventTime;
    }
    
    public abstract void processEvent(Simulator sim);
    
}
