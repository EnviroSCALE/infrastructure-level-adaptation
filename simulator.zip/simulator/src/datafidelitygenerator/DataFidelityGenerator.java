package datafidelitygenerator;

import java.io.FileNotFoundException;

/**
 *
 * @author Hera
 */
public class DataFidelityGenerator {

    public static void main(String[] args) throws FileNotFoundException {
        
        String str = "dummy_trace.txt";
        DataTrace s = new DataTrace(str, 0);
        //s.printReadings();
        
        String str2 = "new.txt";
        DataTrace s2 = new DataTrace(str2, 0);
        
        System.out.println(getMAPE(s2, s));
        
    }
    
    
    public static DataTrace generateDataTrace(double period, DataTrace trace) {
        int count = 0;
        for (double time = 0.0; time <= trace.getMaxTime(); time = time + period) {
            count++;
        }
        ReadingSample[] samples = new ReadingSample[count];
        count = 0;
        for (double time = 0.0; time <= trace.getMaxTime(); time = time + period) {
            double reading = trace.getReading(time);
            ReadingSample sample = new ReadingSample(time, reading, trace.id);
            samples[count++] = sample;
        }
        DataTrace newTrace = new DataTrace(samples, trace.id);
        return newTrace;
    }
    
    
    public static double getMAPE(DataTrace trueTrace, DataTrace reconstructedTrace) {
        double totalError = 0.0;
        int count = 0;
        double maxTime = Math.min(trueTrace.getMaxTime(), reconstructedTrace.getMaxTime());
        double minTime = Math.max(trueTrace.samples[0].time, reconstructedTrace.samples[0].time);
        for (double time = minTime; time <= maxTime; time = time + 0.1) {
            double trueReading = trueTrace.getReading(time);
            double reconstructedReading = reconstructedTrace.getReading(time);
            double ape = Math.abs(trueReading-reconstructedReading)/trueReading*100.0;
            totalError += ape;
            count++;
            //System.out.println(trueReading + " " + reconstructedReading + " " + time);
        }
        return totalError / count;
    }
    
    
}
