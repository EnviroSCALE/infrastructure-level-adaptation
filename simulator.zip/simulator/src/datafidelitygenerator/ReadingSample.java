package datafidelitygenerator;

/**
 *
 * @author Hera
 */
public class ReadingSample {

    @Override
    public String toString() {
        return "ReadingSample{" + "time=" + time + ", reading=" + reading + ", sensorID=" + sensorID + '}';
    }

    @Override
    public int hashCode() {
        int hash = 3;
        hash = 97 * hash + (int) (Double.doubleToLongBits(this.time) ^ (Double.doubleToLongBits(this.time) >>> 32));
        hash = 97 * hash + (int) (Double.doubleToLongBits(this.reading) ^ (Double.doubleToLongBits(this.reading) >>> 32));
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final ReadingSample other = (ReadingSample) obj;
        return true;
    }

    public double getTime() {
        return time;
    }

    public void setTime(double time) {
        this.time = time;
    }

    public double getReading() {
        return reading;
    }

    public void setReading(double reading) {
        this.reading = reading;
    }

    public ReadingSample(double time, double reading, int sensorID) {
        this.time = time;
        this.reading = reading;
        this.sensorID = sensorID;
    }
    
    double time;
    double reading;
    int sensorID;
    
}
