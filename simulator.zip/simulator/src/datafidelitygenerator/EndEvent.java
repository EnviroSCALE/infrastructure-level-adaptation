package datafidelitygenerator;

import java.util.List;

/**
 *
 * @author Hera
 */
public class EndEvent extends Event {
    
    @Override
    public void processEvent(Simulator sim) {
        System.out.println("Simulation ends at: " + sim.simClock);
        
        // uploaded -> data trace
        for (int i = 0; i < sim.numSensors; i++) {
            List<ReadingSample> listOfReadings = sim.uploadedSamples.get(i);
            ReadingSample[] samples = new ReadingSample[listOfReadings.size()];
            int j = 0;
            for (ReadingSample sample : listOfReadings) {
                samples[j++] = sample;
            }
            sim.reconstructedTraces[i] = new DataTrace(samples, i);
        }
    }
    
    EndEvent(double eventTime) {
        super(eventTime);
        this.isEndEvent = true;
    }
    
}
