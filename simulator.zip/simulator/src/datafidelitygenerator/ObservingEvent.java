package datafidelitygenerator;

/**
 *
 * @author Hera
 */
public class ObservingEvent extends Event {
    
    @Override
    public void processEvent(Simulator sim) {
        System.out.println(sim.simClock + "\t" + sim.sensors[2].f);
        sim.eventQueue.add( new ObservingEvent(sim.simClock+5) );
    }
    
    ObservingEvent(double eventTime) {
        super(eventTime);
    }
    
}
