package datafidelitygenerator;

import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedList;
import java.util.List;
import java.util.PriorityQueue;
import java.util.Queue;
import java.util.Random;

/**
 *
 * @author Hera
 */
public class Simulator {
    
    boolean samplingOn = true;
    
    double simClock = 0.0;
    int seed = 123;
    Random random = new Random(seed);
    
    Queue<Event> eventQueue = new PriorityQueue<>(comparator);
    List<ReadingSample> readingQueue = new LinkedList<ReadingSample>();
    Sensor [] sensors;
    ArrayList<ArrayList<ReadingSample>> uploadedSamples;
    DataTrace[] reconstructedTraces;
    
    // inputs
    int numSensors = 5;
    int D = 150000;
    double M = 500.1;
    int alpha = 1024;
    int choice = 3;
    double UploadInterval = 50;
    //stats
    
    int totalUploaded = 0;
    
    public static Comparator<Event> comparator = new Comparator<Event>() {
        @Override
        public int compare(Event e1, Event e2) {
            if (e1.eventTime - e2.eventTime < 0)
                return -1;
            else
                return 1;
        }
    };
    
    public void run() {
        while (!this.eventQueue.isEmpty()) {
            Event e = this.eventQueue.poll();
            if (e == null) {
                break;
            }
            this.simClock = e.eventTime;
            e.processEvent(this);
            if (e.isEndEvent) {
                break;
            }
        }
    }
    
    public void initScene() throws FileNotFoundException {
        this.simClock = 0.0;
        this.eventQueue.add( new EndEvent(this.M) );
        this.eventQueue.add( new UploadEvent(3) );
        this.eventQueue.add( new ObservingEvent(5) );
        
        // do these three at once
        Sensor s1 = new Sensor ("co2", 5, 0, 16, "1.txt", 0);
        Sensor s2 = new Sensor ("methane", 5, 0, 16, "2.txt", 1);
        Sensor s3 = new Sensor ("dust", 5, 0, 16, "3.txt", 2);
        Sensor s4 = new Sensor ("humidity", 1, 1, 16, "4.txt", 3);
        Sensor s5 = new Sensor ("lpg", 1, 1, 16, "5.txt", 4);
        Sensor s6 = new Sensor ("event-triggered", 1, 2, 1024, "new.txt", 5);
        this.sensors = new Sensor[numSensors];
        sensors[0] = s1;
        sensors[1] = s2;
        sensors[2] = s3;
        sensors[3] = s4;
        sensors[4] = s5;
        uploadedSamples = new ArrayList<ArrayList<ReadingSample>>();
        for (int i = 0; i < numSensors; i++) {
            uploadedSamples.add( new ArrayList<ReadingSample>() );
        }
        reconstructedTraces = new DataTrace[numSensors];
        
        this.eventQueue.add( new SensingEvent(0, s1) );
        this.eventQueue.add( new SensingEvent(0, s2) );
        this.eventQueue.add( new SensingEvent(0, s3) );
        this.eventQueue.add( new SensingEvent(0, s4) );
        this.eventQueue.add( new SensingEvent(0, s5) );
        this.eventQueue.add( new SensingEvent(M/2, s6) );
        this.eventQueue.add( new UploadEvent(this.UploadInterval) );
    }
    
    public int getReadingQueueByteSize() {
        int s = 0;
        for (ReadingSample sample : this.readingQueue) {
            s += this.sensors[sample.sensorID].byteSize;
        }
        return s;
    }
    
    public double generateStats() {
        for (int i = 0; i < this.numSensors; i++) {
            DataTrace trueTrace = this.sensors[i].trace;
            DataTrace reconstructedTrace = this.reconstructedTraces[i];
            double mape = DataFidelityGenerator.getMAPE(trueTrace, reconstructedTrace);
            if (i==2) { // the one with max variation in data, dust
                //System.out.println(mape);
                //return mape;
                ;
            }
        }
        return this.totalUploaded*1.0/this.D;
        //System.out.println("Util: " + this.totalUploaded*1.0/this.D);
    }
    
    // generate CV from samples collected so far
    public double getCV (int id) {
        List<ReadingSample> list = this.uploadedSamples.get(id);
        if (list.size() == 0) {
            return -1;
        }
        double sum = 0;
        for (ReadingSample sample : list) {
            sum += sample.reading;
        }
        double mean = sum / list.size();
        sum = 0;
        for (ReadingSample sample : list) {
            sum += (sample.reading-mean)*(sample.reading-mean);
        }
        return sum / list.size();
    }
    
    public static void main(String[] args) throws FileNotFoundException {
        //Simulator sim = new Simulator();

            Simulator sim3 = new Simulator();
            sim3.choice = 3;
            sim3.D = 200000;
            sim3.initScene();
            sim3.run();
        
        
    }
    
}
