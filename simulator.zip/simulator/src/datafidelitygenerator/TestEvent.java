package datafidelitygenerator;

/**
 *
 * @author Hera
 */
public class TestEvent extends Event {

    @Override
    public void processEvent(Simulator sim) {
        sim.eventQueue.add( new TestEvent(sim.simClock+1) );
    }
    
    TestEvent(double eventTime) {
        super(eventTime);
    }
    
}
